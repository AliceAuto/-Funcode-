var initColorpicker = function(){
    Colorpicker.create({
        bindClass: "Colorpicker",
        change: function(elem, hex, gba){
            // console.log(elem);
            // console.log(hex);
            // console.log(gba);

            if ($(elem).attr("type") == "hex")
                $(elem).val(hex);
            else
                $(elem).val("rgba("+gba.r+", "+gba.g+", "+gba.b+", "+gba.a.toFixed(2)+")");


            LiteGUI.trigger(elem, "change" );

            //elem.style.backgroundColor = hex;
        }
    });
}


$(document).ready(function() {
    context.init({preventDoubleContext: false});
    initColorpicker();
});